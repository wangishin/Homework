'''
2. 由使用者分別輸入6個數字並放入串列中, 請用巢狀迴圈進行由大至小排序
   並印出結果(使用者輸入的號碼如果是一樣的不要加進去)

'''


while True:
    score  = list()
    for i in range(6):
        n = int(input("請輸入分數:"))
        score.append(n)
        
    tmp = 0
    length = len(score)
    
    print(length)
    
    for i in range(len(score)):
        for j in range(i + 1, len(score)):
            if score[j] > score[i]:       
                tmp = score[i]
                score[i] = score[j]
                score[j] = tmp            
    print(score) 