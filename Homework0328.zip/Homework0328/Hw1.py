'''
1. 由使用者輸入分數後 找到就移除限用pop找不到顯示找不到


'''

scores = [100, 60, 70, 80, 99, 100, 66]
while True:
    
    n = int(input("請輸入分數:"))
    if n == "":
        break
    if scores.count(n) > 0:
        index = scores.index(n)
        scores.pop(index)
        print(scores)

    else:
        print("找不到!!")