# for...else  
# try....except....else只要沒有被except抓到的就會到否則else去

def divisionNumber(n1, n2):
    try:
        result = n1 // n2
    except Exception as e:
        print(e)
    else:
        print('計算結果', result)
        print('程式執行完畢')
        
        
divisionNumber(10, 2)
divisionNumber(10, 0)


# 判斷質數

for i in range(2, 101):

    for x in range(2, i):       # 質數只能被1跟自己整除
        if i % x == 0:
            break
    else:
        print(i, "是質數")
        
    