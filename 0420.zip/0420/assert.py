# 斷言 assert default = True
# 程式跑到assert如果有報錯可以下判斷是去修

def score(number):
    if number < 0:
        return '不可以小於0'
    else:
        
        assert number >= 0, '輸入值要大於0'
        print('分數:', number)
    
score(60)
score(-60)
    