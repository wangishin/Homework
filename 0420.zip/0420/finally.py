# 今天發生問題時後有甚麼東西一定要做....finally

def divResult(num1, num2):
    
    try:
        result = num1 // num2
        print('結果:', result)
        
    # except Exception as e:
    #     print(e)
        
    finally:        # 一定會執行不管有無錯誤
        print('計算完畢')
    
    

num1 = int(input("Num1:"))    
num2 = int(input("Num2:"))    

divResult(num1, num2)


print("如果exception Exception 被mark掉不會跳出這行")