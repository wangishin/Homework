def showList(datalist, num):
    
    try:
        print(datalist[num])
        
    except IndexError as e:
        print("超出範圍")
        raise IndexError("處理索引問題")      # 外面的要再做例外處理否則會卡在這一段不繼續執行
        
        
try:
    
    data = [10, 20, 30]
    showList(data, 1)
    showList(data, 5)
    
except Exception as e:
    
    print(e)
    
print("程式執行完畢")
        
        
        
    