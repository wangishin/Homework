# try...catch

data = [100, 80, 60, 70]

try:
    print(data(0))
    ans = 100 / 0
    print(data[0])          # 先遇到的error就會跳出去except
    print(data[2])
    print(data[10])

except Exception as ex: 
    print(ex)


 
print("程式執行完畢")