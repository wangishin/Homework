# try...catch

data = [100, 80, 60, 70]

try:
    print(data(0))
    ans = 100 / 0
    print(data[0])          # 先遇到的error就會跳出去except
    print(data[2])
    print(data[10])

except IndexError as ex: 
    print("索引值超過")
except:
    print("其他的error")

'''
    IndexError 超出索引值
    ZeroDivisionError 不得被0除
    
'''
print("程式執行完畢")