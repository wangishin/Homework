# try...catch

data = [100, 80, 60, 70]

try:
    ans = 100 / 0
    print(data[0])
    print(data[2])
    print(data[10])

except IndexError as ex: 
    print("索引值超過")
    
except ZeroDivisionError as ex:
    print("不得被0整除")

    
'''

    IndexError 超出索引值
    ZeroDivisionError 不得被0除
    
'''

print("程式執行完畢")